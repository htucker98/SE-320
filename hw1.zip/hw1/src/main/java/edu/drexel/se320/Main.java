package edu.drexel.se320;

import java.util.Arrays;

public class Main {
    public static void main(String args[]){
        String[] arr = {"AA","A","B","C","abc","bc","c"};
        Arrays.sort(arr);
        int i;

    }
}
